
import React, { useEffect } from 'react';
import { Achievement } from '../types';

interface AchievementToastProps {
  achievement: Achievement | null;
  onClose: () => void;
}

// FIX: Removed the original AchievementToast component that used <style jsx> as it's non-standard and caused type errors.
// The TailwindAchievementToast component below is the correct, working implementation.

// Note: <style jsx> won't work in standard React. This CSS needs to be applied via Tailwind classes or global CSS if needed.
// For simplicity, Tailwind classes or inline styles are preferred.
// The animation can be simplified to:
// className="fixed bottom-5 right-5 bg-primavita-primaryblue text-white p-4 rounded-lg shadow-xl max-w-sm z-50 transform transition-all duration-500 ease-out opacity-0 translate-y-10 data-[visible=true]:opacity-100 data-[visible=true]:translate-y-0"
// And manage a 'visible' state.

// Corrected Tailwind implementation for animation (without style jsx):
const TailwindAchievementToast: React.FC<AchievementToastProps> = ({ achievement, onClose }) => {
  const [isVisible, setIsVisible] = React.useState(false);

  useEffect(() => {
    if (achievement) {
      setIsVisible(true);
      const timer = setTimeout(() => {
        setIsVisible(false);
        // Call onClose after animation out, or immediately if preferred
        setTimeout(onClose, 300); // Wait for fade out
      }, 5000);
      return () => clearTimeout(timer);
    } else {
      setIsVisible(false);
    }
  }, [achievement, onClose]);
  
  if (!achievement && !isVisible) return null; // Don't render if no achievement and not animating out

  return (
    <div 
      className={`fixed bottom-5 right-5 bg-primavita-primaryblue text-white p-4 rounded-lg shadow-xl max-w-xs sm:max-w-sm z-50 transform transition-all duration-300 ease-out
                  ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
    >
      <div className="flex items-center">
        <span className="text-2xl sm:text-3xl mr-3">{achievement?.icon}</span>
        <div>
          <h3 className="font-bold text-base sm:text-lg">Conquista Desbloqueada!</h3>
          {achievement && <p className="text-xs sm:text-sm">{achievement.name_pt}: {achievement.description_pt}</p>}
        </div>
        <button 
            onClick={() => { setIsVisible(false); setTimeout(onClose, 300); }} 
            className="ml-2 sm:ml-4 text-lg font-bold self-start p-1 hover:bg-white/20 rounded-full"
            aria-label="Fechar notificação"
        >
            &times;
        </button>
      </div>
    </div>
  );
};


export default TailwindAchievementToast;