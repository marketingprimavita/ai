
import React from 'react';

export const SyringeIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className || "w-6 h-6"}>
    <path strokeLinecap="round" strokeLinejoin="round" d="m10.061 13.061 2.828-2.828M10.061 13.061v2.828m0-2.828H7.233m6.076 3.579a3 3 0 1 0-4.243-4.242 3 3 0 0 0 4.243 4.242ZM19.5 4.5l-2.474 2.475M10.061 13.061 7.5 15.621m5.036-6.137L15 7.05m-2.474 2.474-1.801 1.801M15 7.05l2.475-2.475M4.5 19.5l2.475-2.475" />
  </svg>
);

export const BeakerIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className || "w-6 h-6"}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9.75 3.104v5.07c0 .79.192 1.531.544 2.161L12 13.528l1.706-3.193a3.75 3.75 0 0 0 .544-2.161V3.104M12 6.032h.008v.008H12V6.032Zm0 0H9.75m2.25 0h2.25M5.25 10.5c0 2.485 2.015 4.5 4.5 4.5s4.5-2.015 4.5-4.5V9H5.25v1.5Z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M5.25 13.528V21h13.5v-7.472M7.5 21V10.5M16.5 21V10.5" />
  </svg>
);

export const SparklesIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className || "w-6 h-6"}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904 9 18.75l-.813-2.846a4.5 4.5 0 0 0-3.09-3.09L1.25 12l2.846-.813a4.5 4.5 0 0 0 3.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 0 0 3.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 0 0-3.09 3.09ZM18.25 7.5l.813 2.846a4.5 4.5 0 0 1 3.09 3.09L22.75 12l-2.846.813a4.5 4.5 0 0 1-3.09 3.09L17.25 18.75l-.813-2.846a4.5 4.5 0 0 1-3.09-3.09L11.25 12l2.846-.813a4.5 4.5 0 0 1 3.09-3.09Z" />
  </svg>
);
