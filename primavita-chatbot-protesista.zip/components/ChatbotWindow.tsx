import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage, Sender, AppView, GameState, GuidedCase } from '../types';
import MessageBubble from './MessageBubble';
import { GUIDED_CASES } from '../constants';
import HiTechToothIcon from './HiTechToothIcon';

interface ChatbotWindowProps {
  messages: ChatMessage[];
  onSendMessage: (text: string, sender: Sender) => void;
  onQuickReply: (payload: string, action_type: 'next_step' | 'product_info' | 'custom_action', points?: number, tip_key?: string) => void;
  currentView: AppView;
  gameState: GameState;
  onSetView: (view: AppView) => void;
  onSelectCase: (caseData: GuidedCase) => void;
}

const ChatbotWindow: React.FC<ChatbotWindowProps> = ({ messages, onSendMessage, onQuickReply, currentView, gameState, onSetView, onSelectCase }) => {
  const [inputValue, setInputValue] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(scrollToBottom, [messages]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputValue(e.target.value);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputValue.trim()) {
      onSendMessage(inputValue, Sender.USER);
      setInputValue('');
    }
  };
  
  const MainMenu: React.FC = () => (
    <div className="p-4 md:p-6 flex flex-col items-center">
        <HiTechToothIcon className="w-24 h-24 mb-4 text-primavita-primaryblue" />
        <h2 className="text-2xl font-bold text-primavita-darkgray mb-2 text-center">Assistente Virtual P.R.I.M.O</h2>
        <p className="text-gray-600 mb-6 text-center">Seu especialista em produtos e técnicas para prótese dentária. 🦷</p>
        <div className="w-full max-w-md space-y-3">
            <button 
                onClick={() => onSetView('catalog')}
                className="w-full bg-primavita-primaryblue text-white font-semibold py-3 px-4 rounded-lg hover:bg-opacity-90 transition-colors shadow-md text-lg"
            >
                🔬 Ver Catálogo Completo
            </button>
            <button 
                onClick={() => onSetView('guided_case_selection')}
                className="w-full bg-primavita-blue text-white font-semibold py-3 px-4 rounded-lg hover:bg-opacity-90 transition-colors shadow-md text-lg"
            >
                ⚙️ Iniciar Caso Clínico Guiado
            </button>
             <p className="text-center text-gray-500 pt-2">Ou digite sua pergunta abaixo para conversar com nossa IA:</p>
        </div>
    </div>
  );

  const GuidedCaseSelection: React.FC = () => (
    <div className="p-4 md:p-6">
        <button onClick={() => onSetView('chat')} className="mb-4 text-primavita-blue hover:underline">&larr; Voltar</button>
        <h2 className="text-2xl font-bold text-primavita-primaryblue mb-6 text-center">Casos Clínicos Guiados 🎓</h2>
        <div className="space-y-4">
            {GUIDED_CASES.map(gc => (
                <button 
                    key={gc.id} 
                    onClick={() => onSelectCase(gc)}
                    className="w-full flex items-center space-x-4 p-4 bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow border border-primavita-primaryblue/30"
                >
                    {React.isValidElement(gc.icon) ?
                        React.cloneElement(gc.icon as React.ReactElement<{ className?: string }>, { 
                            className: "w-10 h-10 text-primavita-primaryblue flex-shrink-0" 
                        })
                        : null
                    }
                    <div className="text-left">
                        <h3 className="text-lg font-semibold text-primavita-blue">{gc.name_pt}</h3>
                        <p className="text-sm text-gray-600">{gc.description_pt}</p>
                    </div>
                </button>
            ))}
        </div>
    </div>
  );


  return (
    <div className="flex flex-col h-full bg-primavita-extralightgray rounded-lg shadow-xl overflow-hidden">
       <header className="bg-white p-4 border-b border-gray-200 shadow-sm">
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <HiTechToothIcon className="w-10 h-10 mr-2 text-primavita-primaryblue"/>
              <h1 className="text-xl font-bold text-primavita-primaryblue">P.R.I.M.O</h1>
            </div>
            <div className="text-right">
              <p className="text-sm font-semibold text-primavita-blue">Pontos: <span className="text-lg">{gameState.score}</span> 🏆</p>
            </div>
          </div>
        </header>

      <div className="flex-grow p-4 overflow-y-auto">
        {currentView === 'chat' && messages.length === 0 && <MainMenu />}
        {currentView === 'chat' && messages.map((msg) => (
          <MessageBubble key={msg.id} message={msg} onQuickReply={onQuickReply} />
        ))}
        {currentView === 'guided_case_selection' && <GuidedCaseSelection />}
        <div ref={messagesEndRef} />
      </div>

      {(currentView === 'chat') && (
        <form onSubmit={handleSubmit} className="p-4 border-t border-gray-200 bg-white">
          <div className="flex items-center space-x-2">
            <input
              type="text"
              value={inputValue}
              onChange={handleInputChange}
              placeholder="Digite sua mensagem ou pergunta..."
              className="flex-grow p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primavita-blue focus:border-transparent outline-none transition-shadow"
              aria-label="Campo de mensagem"
            />
            <button
              type="submit"
              className="bg-primavita-primaryblue text-white p-3 rounded-lg font-semibold hover:bg-opacity-90 transition-colors focus:outline-none focus:ring-2 focus:ring-primavita-blue focus:ring-opacity-50"
              aria-label="Enviar mensagem"
            >
              Enviar
            </button>
          </div>
        </form>
      )}
    </div>
  );
};

export default ChatbotWindow;
