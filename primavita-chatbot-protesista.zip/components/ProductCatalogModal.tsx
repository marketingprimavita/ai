
import React, { useState } from 'react';
import { Product, ProductCategory } from '../types';
import { PRIMAVITA_PRODUCTS } from '../constants';
import CloseIcon from './icons/CloseIcon';
import ChevronDownIcon from './icons/ChevronDownIcon';
import ChevronUpIcon from './icons/ChevronUpIcon';

interface ProductCatalogModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const ProductCatalogModal: React.FC<ProductCatalogModalProps> = ({ isOpen, onClose }) => {
  const [openCategory, setOpenCategory] = useState<ProductCategory | null>(null);

  if (!isOpen) return null;

  const productsByCategory = PRIMAVITA_PRODUCTS.reduce((acc, product) => {
    if (!acc[product.category]) {
      acc[product.category] = [];
    }
    acc[product.category].push(product);
    return acc;
  }, {} as Record<ProductCategory, Product[]>);

  // Define a preferred order for categories
  const categoryOrder: ProductCategory[] = [
    ProductCategory.BLOCOS_CADCAM,
    ProductCategory.DENTES_ACRILICOS,
    ProductCategory.RESINAS_ACRILICAS,
    ProductCategory.CERAS,
    ProductCategory.LIGANTES_GLAZE,
    ProductCategory.ISOLANTES_OPACIFICADORES, // Category for Opacificadores
    ProductCategory.ABRASIVOS,
    ProductCategory.REMOVEDORES_LIMPADORES,
    ProductCategory.ACESSORIOS,
  ];
  
  const displayCategories = categoryOrder.filter(cat => productsByCategory[cat] && productsByCategory[cat].length > 0);

  // Fallback for any categories not in categoryOrder but present in products (should not happen if categoryOrder is comprehensive)
  const remainingCategories = (Object.keys(productsByCategory) as ProductCategory[])
    .filter(cat => !displayCategories.includes(cat))
    .sort((a,b) => a.localeCompare(b));
  
  const allDisplayCategories = [...displayCategories, ...remainingCategories];


  const toggleCategory = (category: ProductCategory) => {
    setOpenCategory(openCategory === category ? null : category);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col">
        <div className="flex justify-between items-center p-6 border-b border-gray-200">
          <h2 className="text-2xl font-bold text-primavita-primaryblue">Catálogo de Produtos Primavita 🔬</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-primavita-darkgray transition-colors">
            <CloseIcon className="w-7 h-7" />
          </button>
        </div>
        
        <div className="p-6 overflow-y-auto space-y-4">
          {allDisplayCategories.length > 0 ? allDisplayCategories.map((category) => (
            <div key={category} className="border border-gray-200 rounded-lg">
              <button
                onClick={() => toggleCategory(category)}
                className="w-full flex justify-between items-center p-4 bg-primavita-extralightgray hover:bg-blue-50 transition-colors rounded-t-lg"
              >
                <h3 className="text-lg font-semibold text-primavita-primaryblue">{category}</h3>
                {openCategory === category ? <ChevronUpIcon className="w-6 h-6 text-primavita-primaryblue" /> : <ChevronDownIcon className="w-6 h-6 text-primavita-primaryblue" />}
              </button>
              {openCategory === category && (
                <div className="p-4 space-y-3 bg-white rounded-b-lg">
                  {productsByCategory[category].map((product) => (
                    <div key={product.id} className="p-3 border border-gray-100 rounded-md shadow-sm hover:shadow-md transition-shadow">
                      <div className="flex items-start space-x-3">
                        {product.image_url && <img src={product.image_url} alt={product.name_pt} className="w-20 h-20 object-cover rounded-md border border-gray-200"/>}
                        <div className="flex-1">
                          <h4 className="font-semibold text-primavita-blue">{product.name_pt}</h4>
                          <p className="text-sm text-gray-700 mt-1">{product.description_pt}</p>
                          {product.usage_tips_pt && product.usage_tips_pt.length > 0 && (
                            <ul className="list-disc list-inside mt-2 text-xs text-gray-600 space-y-1">
                              {product.usage_tips_pt.map((tip, index) => (
                                <li key={index}>{tip}</li>
                              ))}
                            </ul>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )) : (
            <p className="text-center text-gray-500">Nenhum produto encontrado.</p>
          )}
        </div>
         <div className="p-4 border-t border-gray-200 text-right">
            <button
              onClick={onClose}
              className="bg-primavita-primaryblue text-white px-6 py-2 rounded-lg hover:bg-opacity-90 transition-colors font-medium"
            >
              Fechar Catálogo
            </button>
          </div>
      </div>
    </div>
  );
};

export default ProductCatalogModal;