import React, { useState, useEffect } from 'react';
import { GuidedCase, GuidedCaseStep, ChatMessage, Sender, Product, PrimavitaTip } from '../types';
import { PRIMAVITA_PRODUCTS, PRIMAVITA_TIPS } from '../constants';
import MessageBubble from './MessageBubble'; 
import HiTechToothIcon from './HiTechToothIcon';

interface GuidedInteractionProps {
  caseData: GuidedCase;
  onStepComplete: (message: ChatMessage, pointsAwarded: number, productRecommendationId?: string, tipKey?: string, achievementToUnlockId?: string) => void;
  onExit: () => void;
}

const GuidedInteraction: React.FC<GuidedInteractionProps> = ({ caseData, onStepComplete, onExit }) => {
  const [currentStepId, setCurrentStepId] = useState<string>(caseData.start_step_id);
  const currentStep = caseData.steps[currentStepId];

  useEffect(() => {
    if (currentStep && !currentStep.is_final_step) {
      const botMessage: ChatMessage = {
        id: `bot-${Date.now()}`,
        text: currentStep.bot_question_pt,
        sender: Sender.BOT,
        timestamp: new Date(),
        quick_replies: currentStep.options?.map(opt => ({
          text_pt: opt.text_pt,
          payload: opt.next_step_id || 'exit_case', 
          action_type: 'next_step',
          points: opt.points,
          tip_key: opt.tip_key
        }))
      };
    } else if (currentStep && currentStep.is_final_step) {
        const finalBotMessage: ChatMessage = {
            id: `bot-final-${Date.now()}`,
            text: currentStep.bot_question_pt,
            sender: Sender.BOT,
            timestamp: new Date(),
        };
        onStepComplete(finalBotMessage, 0, undefined, undefined, currentStep.achievement_unlock_id);
    }
  }, [currentStepId, caseData, currentStep, onStepComplete]);

  const handleOptionSelect = (nextStepId: string | null | undefined, points: number = 0, productRecommendationId?: string, tipKey?: string, achievementId?: string) => {
    if (!currentStep || !currentStep.options) return;

    const selectedOptionText = currentStep.options.find(opt => opt.next_step_id === nextStepId)?.text_pt || "Opção selecionada";

    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      text: selectedOptionText,
      sender: Sender.USER,
      timestamp: new Date(),
    };
    onStepComplete(userMessage, 0); 

    if (nextStepId && caseData.steps[nextStepId]) {
      const nextStepDetails = caseData.steps[nextStepId];
      const botResponseText = nextStepDetails.bot_question_pt;
      
      const botMessage: ChatMessage = {
        id: `bot-${Date.now() + 1}`,
        text: botResponseText,
        sender: Sender.BOT,
        timestamp: new Date(),
        quick_replies: nextStepDetails.options?.map(opt => ({
            text_pt: opt.text_pt,
            payload: opt.next_step_id || 'exit_case',
            action_type: 'next_step',
            points: opt.points,
            tip_key: opt.tip_key,
        })),
        product_recommendation_id: productRecommendationId,
        tip_key: tipKey,
      };
      onStepComplete(botMessage, points, productRecommendationId, tipKey, achievementId || nextStepDetails.achievement_unlock_id || nextStepDetails.options?.find(opt => opt.achievement_unlock_id)?.achievement_unlock_id);
      setCurrentStepId(nextStepId);

    } else { 
      const endMessage: ChatMessage = {
        id: `bot-end-${Date.now() + 1}`,
        text: "Caso concluído ou esta ramificação terminou. Obrigado! ✨",
        sender: Sender.BOT,
        timestamp: new Date(),
      };
      onStepComplete(endMessage, points, productRecommendationId, tipKey, achievementId || currentStep.achievement_unlock_id);
      onExit();
    }
  };

  if (!currentStep) {
    return <div className="p-4 text-red-500">Erro: Passo do caso não encontrado.</div>;
  }
  
  const primaryOption = currentStep.options?.[0];
  const product = primaryOption?.product_recommendation_id ? PRIMAVITA_PRODUCTS.find(p => p.id === primaryOption.product_recommendation_id) : null;
  const tip = primaryOption?.tip_key ? PRIMAVITA_TIPS.find(t => t.key === primaryOption.tip_key) : null;


  return (
    <div className="p-4 md:p-6 bg-primavita-extralightgray rounded-lg shadow-lg w-full max-w-xl mx-auto">
      <div className="flex items-center mb-4">
        <HiTechToothIcon className="w-12 h-12 mr-3 text-primavita-primaryblue"/>
        <div>
            <h2 className="text-xl font-bold text-primavita-primaryblue">{caseData.name_pt}</h2>
            <p className="text-sm text-gray-600">{caseData.description_pt}</p>
        </div>
      </div>

      <div className="mb-6 p-4 bg-white rounded-lg shadow ring-1 ring-primavita-primaryblue/20">
        <p className="text-lg font-medium text-primavita-darkgray">{currentStep.bot_question_pt}</p>
      </div>
      
      {product && (
        <div className="mb-4 p-3 bg-blue-50 border border-primavita-blue/30 rounded-lg">
          <h4 className="font-semibold text-primavita-blue mb-1">💡 Produto Primavita Sugerido: {product.name_pt}</h4>
          <div className="flex items-center space-x-3">
            {product.image_url && <img src={product.image_url} alt={product.name_pt} className="w-16 h-16 object-cover rounded"/>}
            <p className="text-xs text-gray-700">{product.description_pt}</p>
          </div>
        </div>
      )}
      {tip && (
        <div className="mb-4 p-3 bg-yellow-50 border border-yellow-300 rounded-lg">
          <h4 className="font-semibold text-yellow-700 mb-1">{tip.emoji || '💡'} Dica Primavita:</h4>
          <p className="text-xs text-yellow-600">{tip.text_pt}</p>
        </div>
      )}

      {currentStep.options && !currentStep.is_final_step && (
        <div className="space-y-3">
          {currentStep.options.map((option, index) => (
            <button
              key={index}
              onClick={() => handleOptionSelect(option.next_step_id, option.points, option.product_recommendation_id, option.tip_key, option.achievement_unlock_id)}
              className="w-full bg-primavita-primaryblue text-white font-semibold py-3 px-4 rounded-lg hover:bg-opacity-90 transition-colors duration-150 shadow-md focus:outline-none focus:ring-2 focus:ring-primavita-blue focus:ring-opacity-50"
            >
              {option.text_pt} {option.points ? `(+${option.points} pts)` : ''}
            </button>
          ))}
        </div>
      )}

      {currentStep.is_final_step && (
         <div className="mt-6 p-4 bg-green-50 border border-green-300 rounded-lg text-center">
            <p className="text-sm text-green-600 mt-1">Você completou o caso! Verifique suas conquistas!</p>
         </div>
      )}

      <button
        onClick={onExit}
        className="mt-8 w-full bg-gray-200 text-gray-700 font-medium py-2 px-4 rounded-lg hover:bg-gray-300 transition-colors duration-150"
      >
        {currentStep.is_final_step ? "Voltar ao Menu Principal" : "Sair do Caso Clínico"}
      </button>
    </div>
  );
};

export default GuidedInteraction;
