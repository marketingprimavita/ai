import React from 'react';
import { ChatMessage, Sender, Product, PrimavitaTip } from '../types';
import { PRIMAVITA_PRODUCTS, PRIMAVITA_TIPS } from '../constants';
import BotIcon from './icons/BotIcon';
import UserIcon from './icons/UserIcon';
import HiTechToothIcon from './HiTechToothIcon';

interface MessageBubbleProps {
  message: ChatMessage;
  onQuickReply: (payload: string, action_type: 'next_step' | 'product_info' | 'custom_action', points?: number, tip_key?: string) => void;
}

const MessageBubble: React.FC<MessageBubbleProps> = ({ message, onQuickReply }) => {
  const isUser = message.sender === Sender.USER;
  const product = message.product_recommendation_id ? PRIMAVITA_PRODUCTS.find(p => p.id === message.product_recommendation_id) : null;
  const tip = message.tip_key ? PRIMAVITA_TIPS.find(t => t.key === message.tip_key) : null;

  return (
    <div className={`flex mb-4 ${isUser ? 'justify-end' : 'justify-start'}`}>
      <div className={`flex items-end max-w-lg ${isUser ? 'flex-row-reverse' : ''}`}>
        {isUser ? (
          <UserIcon className="w-8 h-8 p-1 rounded-full bg-primavita-blue text-white ml-2" />
        ) : (
          <HiTechToothIcon className="w-10 h-10 mr-2 self-start text-primavita-primaryblue" />
        )}
        <div
          className={`py-3 px-4 rounded-xl shadow-md ${
            isUser
              ? 'bg-primavita-blue text-white rounded-br-none'
              : 'bg-white text-primavita-darkgray rounded-bl-none border border-primavita-primaryblue/30'
          }`}
        >
          <p className="text-sm whitespace-pre-wrap">{message.text}</p>
          {product && (
            <div className="mt-3 p-3 bg-primavita-extralightgray rounded-lg border border-primavita-primaryblue/50">
              <h4 className="font-semibold text-primavita-primaryblue mb-1">💡 Produto Recomendado: {product.name_pt}</h4>
              <p className="text-xs text-gray-700 mb-1">{product.description_pt}</p>
              {product.image_url && <img src={product.image_url} alt={product.name_pt} className="w-20 h-20 object-cover rounded my-2"/>}
              {product.usage_tips_pt?.map((tip, index) => (
                <p key={index} className="text-xs text-gray-600 mt-1">🔸 {tip}</p>
              ))}
            </div>
          )}
          {tip && (
            <div className="mt-3 p-3 bg-yellow-50 border border-yellow-300 rounded-lg">
              <h4 className="font-semibold text-yellow-700 mb-1">{tip.emoji || '💡'} Dica Primavita:</h4>
              <p className="text-xs text-yellow-600">{tip.text_pt}</p>
            </div>
          )}
          {message.quick_replies && message.quick_replies.length > 0 && (
            <div className="mt-3 space-y-2">
              {message.quick_replies.map((reply, index) => (
                <button
                  key={index}
                  onClick={() => onQuickReply(reply.payload, reply.action_type, reply.points, reply.tip_key)}
                  className="w-full text-left bg-primavita-primaryblue/10 hover:bg-primavita-primaryblue/20 text-primavita-primaryblue font-medium py-2 px-3 rounded-md text-xs transition-colors duration-150"
                >
                  {reply.text_pt}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default MessageBubble;
