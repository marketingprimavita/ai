import React from 'react';
import GenericToothIcon from './icons/GenericToothIcon'; // Import the new generic tooth icon

interface HiTechToothIconProps {
  className?: string;
}

const HiTechToothIcon: React.FC<HiTechToothIconProps> = ({ className }) => {
  return (
    <GenericToothIcon className={className} />
  );
};

export default HiTechToothIcon;
