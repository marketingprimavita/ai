
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { SYSTEM_INSTRUCTION_GEMINI } from '../constants';

// FIX: Initialize GoogleGenAI directly with process.env.API_KEY as per guidelines.
// Assume process.env.API_KEY is pre-configured, valid, and accessible.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateContentWithGemini = async (prompt: string): Promise<string> => {
  // FIX: Removed pre-check for API_KEY. If API_KEY is missing or invalid,
  // the API call itself will fail, and this will be caught by the try-catch block.
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-2.5-flash-preview-04-17', // Using the specified model
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION_GEMINI,
        temperature: 0.7, // Adjust for creativity vs. factuality
        topK: 40,
        topP: 0.95,
        // thinkingConfig: { thinkingBudget: 0 } // Disable thinking for faster, potentially less nuanced responses. Omit for higher quality.
      },
    });
    return response.text;
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    if (error instanceof Error && error.message.includes('API key not valid')) {
        return "Desculpe, parece haver um problema com a chave de API do serviço de IA. Por favor, avise o administrador. 🔑";
    }
    // Add a check for other common API errors if needed, e.g., quota issues, resource exhausted.
    // For now, a generic message for other errors.
    return "Desculpe, não consegui processar sua pergunta no momento. Tente novamente mais tarde ou explore outras opções. ⚙️";
  }
};
